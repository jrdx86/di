#! /usr/bin/python3
from random import randint

y = randint(1,10)#Generemos un numero entre 1 y 10
x=None

while x!=y:#mientras sean diferentes numeros no parara el bucle
    try:
        x = int(input("Introduce un numero para adivinar entre 1 y 10: "))
    except:
        print("Warning: Necesito un numero entero!")#dara error cuando no sea un numero entero


print("Lo adivinaste era",y)#cuando salga el bucle nos avisara diciendo el numero

